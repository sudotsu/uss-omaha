
export function SectionDivider() {
  return <div className="h-px bg-neutral-light my-12 print:my-6" />
}
